wyymserver.py和wyymclient.py为最终版本服务端和客户端程序<br>p0.gif和p1.gif为客户端UI所需背景图片<br>

通过python locust进行并发测试<br>locustfile.py为客户端并发测试文件<br>server_select.py为高并发解决后客户端测试文件<br>select.png和select.html为server_select.py测试结果<br>server_multiprocess.py为高并发解决前客户端测试文件<br>multiprocess.png和multiprocess.html为server_multiprocess.py测试结果

serverfiles为服务端文件资源文件夹<br>客户端下载的文件保存在当前文件夹